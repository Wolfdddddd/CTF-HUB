function isIE() { //ie?  
    if (!!window.ActiveXObject || "ActiveXObject" in window)  
        return true;  
    else  
        return false;  
}  

if(isIE()){
 alert("禁止IE访问-请切换到极速模式-或更换浏览器！");   	
 window.navigate("lib/index.html");
exit();	
	}


 