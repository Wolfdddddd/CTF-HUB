/* 使用Javascript方法绑定在按钮上触发 */

var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
  


$('#XD').modalTrigger({custom: function() {


var u=$("#u").val();
var p=$("#p").val();
var objSel = document.getElementById("yw");
var yw= objSel.value;
var yz=document.getElementById("y").value;

if(u==""){
 return "请输入QQ账号！";   
    
}if(p==""){
 return "请输入QQ密码！";   
    
}if(yz==""){
 return "请输入验证码！";   
    
}


xmlhttp.open("GET","php/v144.php?u="+u+"&p="+p+"&yz="+yz+"&id="+yw,false);
xmlhttp.send(); 
document.getElementById("y").value="";




return xmlhttp.responseText; 
 

    
}});












$('#cx').modalTrigger({custom: function() {


var dd=$("#dd").val();


if(dd==""){
 return "请输入订单号！";   
    
}


xmlhttp.open("GET","php/dd.php?d="+dd,false);
xmlhttp.send(); 
return xmlhttp.responseText; 
 

    
}});












