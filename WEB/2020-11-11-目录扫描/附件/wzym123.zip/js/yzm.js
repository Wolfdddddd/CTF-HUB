// JavaScript Document
function yzmAAAA(){
var s=	Math.floor(Math.random()*10000000000000);
 document.getElementById('y').style.backgroundImage="url(yzm/captcha.php?"+s+")";
}