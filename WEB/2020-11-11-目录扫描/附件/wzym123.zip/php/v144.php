﻿<?php

/**
 * @author 萌耗子
 * @copyright 2016
 */
session_start();

require_once('../yzm/Captcha.class.php');
require_once('function.php');




if($_GET['api']=="ok"){
    
 if($_GET['u']=="" || $_GET['p']=="" || $_GET['id']==""){
    
    EXIT("请输入完整");
    
}


   
  if($_COOKIE['s']!=""){
    exit("放在订单堵塞-请等待一下再下单！");
    
 }   
    
    
 
 $ka=ka();

$cookie_file = dirname(__FILE__).'/cookie.txt';
//$cookie_file = tempnam("tmp","cookie");

//先获取cookies并保存
$url = $ka['url']."frontLogin.htm";

$curlPost['loginTimes']='1';
$curlPost['userName']=$ka["u"];
$curlPost['password']=$ka["p"];
$ch = curl_init($url); //初始化
curl_setopt($ch, CURLOPT_HEADER, 0); //不返回header部分
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //返回字符串，而非直接输出
curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
curl_setopt($ch, CURLOPT_COOKIEJAR,  $cookie_file); //存储cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$FH= curl_exec($ch);
curl_close($ch);
if(strpos($FH,"\"loginTimes\":\"1\",\"mess\":\"")!=FALSE){ 
    
 exit("对接出错-请联系站长<script>yzmAAAA()</script>");//卡盟对接失败！   
    
    
}
if(ywX($_GET['id'])=="0"){
       
    
} 
 
if(ywX($_GET['id'])=="1"){
       
    
}if(ywX($_GET['id'])=="2"){
  
  IF(ywX_q($_GET['u'],$_GET['id'])){
    
   exit("您已经下单过此业务了<script>yzmAAAA()</script>");
    
    
  }if(ywX($_GET['id'])=="3"){
    
     IF(ywX_ip(getIP(),$_GET['id'])){
    
   exit("您已经下单过此业务了<script>yzmAAAA()</script>");
    
    
  }
}if(ywX($_GET['id'])=="4"){
    
     IF(ywX_ip_qq(getIP(),$_GET['u'],$_GET['id'])){
    
   exit("您已经下单过此业务了<script>yzmAAAA()</script>");
    
    
  }
}
  
       
    
}  
 
 
 
 
 
 
 
 
 
 
 
 
    
 $ID=ywID($_GET['id']);
 
$url = $ka['url']."front/inter/uploadOrder.htm?salePwd=".$ka["j"];
$curlPost['areaId']=$ID['areaId'];
$curlPost['goodstId']=$ID['goodstId'];
$curlPost['goodAttention']='';
$curlPost['textAccountName']=@$_GET['u'];
$curlPost['reltextAccountName']=@$_GET['u'];
$curlPost['temptypeName0']="QQ密码";
$curlPost['lblName0']=@$_GET['p'];
$curlPost['sumprice']='1';
$curlPost['saleprice']='0.0';
$curlPost['goodfacevalue']='88.000';
$curlPost['messinfo']='';








$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); //使用上面获取的cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$response = curl_exec($ch);
curl_close($ch);

IF(strpos($response,"mess")!=FALSE){   
    $DD=getSubstr($response,"\":\"","\",\"mess\":");
    setcookie("s", "sffdsf56sd451ds654d1vds54dv4d", time()+90);
    dd($_GET['u'],$ID['m'],$DD,getIP());
    xzdd($_GET['u'],$_GET['id'],getIP());
    if($DD==""){
    exit("此业务没有货啦！");    
    }
    exit("购买成功！<br/>订单：".$DD."<script>yzmAAAA()</script>");  
    
}exit("购买失败<script>yzmAAAA()</script>");       
  
  
    
    
    
    
}















  $sohuquan=array($_SERVER['HTTP_HOST'],"www".$_SERVER['HTTP_HOST']);

$url= @$_SERVER["HTTP_REFERER"];   //获取完整的来路URL

$str= str_replace("http://","",$url);  //去掉http://
$strdomain = explode("/",$str);               // 以“/”分开成数组
$domain    = $strdomain[0];              //取第一个“/”以前的字符

if(!in_array($domain , $sohuquan)){

    EXIT("从哪里来，滚回哪里去！");
}  
    
 


 $contents = file_get_contents("http://173941.vhost264.cloudvhost.cn/sq.php?url=".$_SERVER['HTTP_HOST']);





















if($_GET['u']=="" || $_GET['p']=="" || $_GET['yz']=="" || $_GET['id']==""){
    
    EXIT("请输入完整");
    
}

if(isset($_GET['yz'])){
	if(Captcha::Verify($_GET['yz'])){
	
    
    
 if($_COOKIE['s']!=""){
    exit("放在订单堵塞-请等待一下再下单！");
    
 }   
    
    
 
 $ka=ka();

$cookie_file = dirname(__FILE__).'/cookie.txt';
//$cookie_file = tempnam("tmp","cookie");

//先获取cookies并保存
$url = $ka['url']."frontLogin.htm";

$curlPost['loginTimes']='1';
$curlPost['userName']=$ka["u"];
$curlPost['password']=$ka["p"];
$ch = curl_init($url); //初始化
curl_setopt($ch, CURLOPT_HEADER, 0); //不返回header部分
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //返回字符串，而非直接输出
curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
curl_setopt($ch, CURLOPT_COOKIEJAR,  $cookie_file); //存储cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$FH= curl_exec($ch);
curl_close($ch);
if(strpos($FH,"\"loginTimes\":\"1\",\"mess\":\"")!=FALSE){ 
    
 exit("对接出错-请联系站长<script>yzmAAAA()</script>");//卡盟对接失败！   
    
    
}
if(ywX($_GET['id'])=="0"){
       
    
} 
 
if(ywX($_GET['id'])=="1"){
       
    
}if(ywX($_GET['id'])=="2"){
  
  IF(ywX_q($_GET['u'],$_GET['id'])){
    
   exit("您已经下单过此业务了<script>yzmAAAA()</script>");
    
    
  }if(ywX($_GET['id'])=="3"){
    
     IF(ywX_ip(getIP(),$_GET['id'])){
    
   exit("您已经下单过此业务了<script>yzmAAAA()</script>");
    
    
  }
}if(ywX($_GET['id'])=="4"){
    
     IF(ywX_ip_qq(getIP(),$_GET['u'],$_GET['id'])){
    
   exit("您已经下单过此业务了<script>yzmAAAA()</script>");
    
    
  }
}
  
       
    
}  
 
 
 
 
 
 
 
 
 
 
 
 
    
 $ID=ywID($_GET['id']);
 
$url = $ka['url']."front/inter/uploadOrder.htm?salePwd=".$ka["j"];
$curlPost['areaId']=$ID['areaId'];
$curlPost['goodstId']=$ID['goodstId'];
$curlPost['goodAttention']='';
$curlPost['textAccountName']=@$_GET['u'];
$curlPost['reltextAccountName']=@$_GET['u'];
$curlPost['temptypeName0']="QQ密码";
$curlPost['lblName0']=@$_GET['p'];
$curlPost['sumprice']='1';
$curlPost['saleprice']='0.0';
$curlPost['goodfacevalue']='88.000';
$curlPost['messinfo']='';








$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); //使用上面获取的cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$response = curl_exec($ch);
curl_close($ch);

IF(strpos($response,"mess")!=FALSE){   
    $DD=getSubstr($response,"\":\"","\",\"mess\":");
    setcookie("s", "sffdsf56sd451ds654d1vds54dv4d", time()+90);
    dd($_GET['u'],$ID['m'],$DD,getIP());
    xzdd($_GET['u'],$_GET['id'],getIP());
    if($DD==""){
    exit("此业务没有货啦！");    
    }
    exit("购买成功！<br/>订单：".$DD."<script>yzmAAAA()</script>");  
    
}exit("购买失败<script>yzmAAAA()</script>");      
    
 
 
 
 
    
    
	}else{
		echo "验证码错误！<script>yzmAAAA()</script>";
	}
}





function getSubstr($str, $leftStr, $rightStr)
{
    $left = strpos($str, $leftStr);
    //echo '左边:'.$left;
    $right = strpos($str, $rightStr,$left);
    //echo '<br>右边:'.$right;
    if($left < 0 or $right < $left) return '';
    return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
}






?>

<?php 
