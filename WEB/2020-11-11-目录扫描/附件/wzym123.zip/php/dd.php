<?php

/**
 * @author �Ⱥ���
 * @copyright 2016
 */

include("function.php");

$ka=ka();

    
$cookie_file = dirname(__FILE__).'/cookie.txt';
//$cookie_file = tempnam("tmp","cookie");

//�Ȼ�ȡcookies������
$url = $ka['url']."frontLogin.htm";

$curlPost['loginTimes']='1';
$curlPost['userName']=$ka["u"];
$curlPost['password']=$ka["p"];
$ch = curl_init($url); //��ʼ��
curl_setopt($ch, CURLOPT_HEADER, 0); //������header����
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //�����ַ���������ֱ�����
curl_setopt($ch, CURLOPT_POST, 1);//post�ύ��ʽ
curl_setopt($ch, CURLOPT_COOKIEJAR,  $cookie_file); //�洢cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$FH= curl_exec($ch);
curl_close($ch);
if(strpos($FH,"\"loginTimes\":\"1\",\"mess\":\"")!=FALSE){ 
    
 exit("1");//���˶Խ�ʧ�ܣ�   
    
    
}

$SJ= date('Y-m-d',time());
$url = $ka['url']."front/inter/salelist.htm";
$curlPost['inputKeyWord']=@$_GET['d'];
$curlPost['inputKeyValue']='2';
$curlPost['goodType']='0';
$curlPost['startTime']=$SJ;
$curlPost['endTime']='2018-01-01';
$curlPost['nowPage']='1';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, 1);//post�ύ��ʽ
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); //ʹ�������ȡ��cookies
curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
$response = curl_exec($ch);
curl_close($ch);


IF(strpos($response,"等待处理")!=FALSE){
    
    exit(iconv('GBK', 'UTF-8', "�����ȴ�������"));
    
}IF(strpos($response,"交易成功")!=FALSE){
    exit(iconv('GBK', 'UTF-8', "��ֵ�ɹ�"));
  
    
}IF(strpos($response,"交易取消")!=FALSE){
    $ID=getSubstr($response,"<a href=\"javascript:void(0);\" name=\"showorder\" id=\"","\">");
    
    
    
    $url =$ka['url']. "front/inter/showordermess.htm?orderid=".$ID;
    
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); //ʹ�������ȡ��cookies
    curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
    $response = curl_exec($ch);
    curl_close($ch); 
    
    $JG=getSubstr($response,"充值信息：</label>","</span>");
    IF($JG!=""){
      header('Content-Type: text/html; charset=utf-8');  
      $JG=trim($JG);
      exit($JG);  
        
    }exit(iconv('GBK', 'UTF-8', "������ѯʧ��"));
 
    
    
    
    
    
}exit(iconv('GBK', 'UTF-8', "���޴˶���"));













function getSubstr($str, $leftStr, $rightStr)
{
    $left = strpos($str, $leftStr);
    //echo '���:'.$left;
    $right = strpos($str, $rightStr,$left);
    //echo '<br>�ұ�:'.$right;
    if($left < 0 or $right < $left) return '';
    return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
}






?>