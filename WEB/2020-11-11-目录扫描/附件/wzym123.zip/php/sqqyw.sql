/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50553
 Source Host           : localhost:3306
 Source Schema         : sqqyw

 Target Server Type    : MySQL
 Target Server Version : 50553
 File Encoding         : 65001

 Date: 10/11/2020 19:15:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `u` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `p` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'admin', 'admin');

-- ----------------------------
-- Table structure for advertising
-- ----------------------------
DROP TABLE IF EXISTS `advertising`;
CREATE TABLE `advertising`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `s` varchar(9999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `x` varchar(9999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of advertising
-- ----------------------------
INSERT INTO `advertising` VALUES (1, '', '');

-- ----------------------------
-- Table structure for announcement
-- ----------------------------
DROP TABLE IF EXISTS `announcement`;
CREATE TABLE `announcement`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `announcement` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of announcement
-- ----------------------------
INSERT INTO `announcement` VALUES (1, '');

-- ----------------------------
-- Table structure for bottom
-- ----------------------------
DROP TABLE IF EXISTS `bottom`;
CREATE TABLE `bottom`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `bottom` varchar(9999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of bottom
-- ----------------------------
INSERT INTO `bottom` VALUES (1, '');

-- ----------------------------
-- Table structure for dd
-- ----------------------------
DROP TABLE IF EXISTS `dd`;
CREATE TABLE `dd`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `u` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `m` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `d` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ip` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of dd
-- ----------------------------
INSERT INTO `dd` VALUES (4, '554425155', '（QQ咨询达人图标）永久性点亮ˇ软件7*24小时自动开单', '20160718362148234844421', '127.0.0.1');

-- ----------------------------
-- Table structure for flag
-- ----------------------------
DROP TABLE IF EXISTS `flag`;
CREATE TABLE `flag`  (
  `flag` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of flag
-- ----------------------------
INSERT INTO `flag` VALUES ('flag{!@#$kobi123}');

-- ----------------------------
-- Table structure for ka
-- ----------------------------
DROP TABLE IF EXISTS `ka`;
CREATE TABLE `ka`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `url` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `u` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `p` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `j` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ka
-- ----------------------------
INSERT INTO `ka` VALUES (1, 'http://danran.999km.cn/', '卡盟账号', '卡盟密码', '交易密码');

-- ----------------------------
-- Table structure for title
-- ----------------------------
DROP TABLE IF EXISTS `title`;
CREATE TABLE `title`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `t` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `g` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `m` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `q` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tt` varchar(999) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of title
-- ----------------------------
INSERT INTO `title` VALUES (1, '淡然点图标系统', '淡然点图标系统', '淡然点图标系统是一个在线点亮QQ图标的网站', '2243752917', '淡然点图标系统');

-- ----------------------------
-- Table structure for xz
-- ----------------------------
DROP TABLE IF EXISTS `xz`;
CREATE TABLE `xz`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `ip` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `q` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `y` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of xz
-- ----------------------------

-- ----------------------------
-- Table structure for yw
-- ----------------------------
DROP TABLE IF EXISTS `yw`;
CREATE TABLE `yw`  (
  `id` int(99) NOT NULL AUTO_INCREMENT,
  `m` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `areaId` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `goodstId` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `x` varchar(99) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of yw
-- ----------------------------
INSERT INTO `yw` VALUES (1, '（永久纪念超Q）需曾经开过超Q或现在是会员', '11324127', '13796230', '');
INSERT INTO `yw` VALUES (2, '（永久情侣黄钻图标）需本身自带黄钻黄钻多久就卡多久', '11324128', '13796282', '');
INSERT INTO `yw` VALUES (3, '（永久旋风图标）需QQ会员或者超级会员', '11324129', '13796383', '');
INSERT INTO `yw` VALUES (4, '（临时图书vip）官方一天图书一个月一次', '11324130', '13796445', '');
INSERT INTO `yw` VALUES (5, '（手机拉圈圈，圈圈赞，7个个性标签赞，拉满99 、秒拉爆满）', '11324131', '13796495', '');
INSERT INTO `yw` VALUES (6, '（3399游戏小图标）日开万单下单就秒', '11324132', '13796518', '');
INSERT INTO `yw` VALUES (7, '（永久星钻图标）需本身自带官方黄钻绿钻多久就卡多久', '11324133', '13796642', '');
INSERT INTO `yw` VALUES (8, '（永久透明头像）需QQ会员或者超级会员-日开万单', '11324135', '13796855', '');
INSERT INTO `yw` VALUES (9, '（QQ咨询达人图标）永久性点亮ˇ软件7*24小时自动开单', '17679275', '20334540', '');

SET FOREIGN_KEY_CHECKS = 1;
