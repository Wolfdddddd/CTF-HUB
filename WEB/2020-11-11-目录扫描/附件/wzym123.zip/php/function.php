<?php

/**
 * @author �Ⱥ���
 * @copyright 2016
 */

include("conn.php");
$GLOBALS['D']=$D;

//====================================================================================================
//��վ�������
function zl(){
    
  $SQL="SELECT * FROM  `title` LIMIT 0 , 1";
  $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj;
}
//====================================================================================================
//��վ�������
function announcement(){
    
  $SQL="SELECT * FROM  `announcement` LIMIT 0 , 1";
  $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj['announcement'];
}
//====================================================================================================
//��վ������
function advertising(){
    
  $SQL="SELECT * FROM  `advertising` LIMIT 0 , 1";
  $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj;
}
//====================================================================================================
//��վ�ײ����
function bottom(){
    
  $SQL="SELECT * FROM  `bottom` LIMIT 0 , 1";
  $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj['bottom'];
}
//====================================================================================================
//��վ�������
function ka(){
    
  $SQL="SELECT * FROM  `ka` LIMIT 0 , 1";
  $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj;
}
//====================================================================================================
//��վ���ҵ���б�

function ywlb(){
    
    $SQL="SELECT * FROM  `yw` LIMIT 0 , 300";
    $FH=mysql_query($SQL);
    while($SJ=mysql_fetch_array($FH)){
        
        echo("<option value='".$SJ['id']."' selected='selected'>".$SJ['m']."</option>");
        
    }
    
    
}
//====================================================================================================
//��վ���ҵ��ID
function ywID($ID){
    
    $SQL="SELECT * FROM  `yw` WHERE  `id` =".$ID." LIMIT 0 , 30";
    $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj;
    
    
}
//====================================================================================================

//���涩��
function dd($U,$M,$D,$ip){
    
    $SQL="INSERT INTO  `".$GLOBALS['D']."`.`dd` (
`id` ,
`u` ,
`m` ,
`d` ,
`ip`
)
VALUES (
NULL ,  '".$U."',  '".$M."',  '".$D."',  '".$ip."'
);
";
  if(mysql_query($SQL)){
    return   true;  
    
}else{
    return   false;  
    
} 
    
    
}
//====================================================================================================
//�������
function ywdd($ip){
    
    $SQL="SELECT * FROM  `dd` WHERE  `ip` LIKE  '".$ip."'LIMIT 0 , 30";
    $FH=mysql_query($SQL);
    while($sj=mysql_fetch_array($FH)){
        
     echo(" <tr>
            <td>".$sj['u']."</td>
            <td class=\"hidden-xs\">".$sj['m']."</td>
            <td>|".$sj['d']."</td>
      
          </tr>");   
    }
    
    
    
    
}

//====================================================================================================
//���ҵ������
function ywX($ID){
    
    $SQL="SELECT * FROM  `yw` WHERE  `id` =".$ID." LIMIT 0 , 1";
    echo $SQL;
    $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  return   $sj['x'];
    
    
}
//====================================================================================================
//ҵ������QQ��ѯ
function ywX_q($qq,$YW){
    
    $SQL="SELECT * 
FROM  `xz` 
WHERE  `q` LIKE  '".$qq."'
AND  `y` LIKE  '".$YW."'
LIMIT 0 , 30";
    $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  
  
    if($sj['id']!=""){
    return   true;  
    
}else{
    return   false;  
    
}
  

    
    
}
//====================================================================================================
//ҵ������ip��ѯ
function ywX_ip($ip,$YW){
    
    $SQL="SELECT * 
FROM  `xz` 
WHERE  `ip` LIKE  '".$ip."'
AND  `y` LIKE  '".$YW."'
LIMIT 0 , 30";
    $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  
  
    if($sj['id']!=""){
    return   true;  
    
}else{
    return   false;  
    
}
  

    
    
}
//====================================================================================================
//ҵ������ip QQ��ѯ
function ywX_ip_qq($ip,$QQ,$YW){
    
    $SQL="SELECT * 
FROM  `xz` 
WHERE  `ip` LIKE  '".$ip."'
AND  `q` LIKE  '".$QQ."'
AND  `y` LIKE  '".$YW."'
LIMIT 0 , 30";
    $FH=mysql_query($SQL);
  $sj=mysql_fetch_array($FH);
  
  
    if($sj['id']!=""){
    return   true;  
    
}else{
    return   false;  
    
}
  

    
    
}
//====================================================================================================
//���涩��
function xzdd($U,$Y,$ip){
    
 $SQL="INSERT INTO  `".$GLOBALS['D']."`.`xz` (
`id` ,
`ip` ,
`q` ,
`y`
)
VALUES (
NULL ,  '',  '',  ''
), (
NULL ,  '".$ip."',  '".$U."',  '".$Y."'
);
"   ;
    
    

  if(mysql_query($SQL)){
    return   true;  
    
}else{
    return   false;  
    
} 
    
    
}
//====================================================================================================




















function getIP()
{
    static $realip;
    if (isset($_SERVER)){
        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
            $realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
            $realip = $_SERVER["HTTP_CLIENT_IP"];
        } else {
            $realip = $_SERVER["REMOTE_ADDR"];
        }
    } else {
        if (getenv("HTTP_X_FORWARDED_FOR")){
            $realip = getenv("HTTP_X_FORWARDED_FOR");
        } else if (getenv("HTTP_CLIENT_IP")) {
            $realip = getenv("HTTP_CLIENT_IP");
        } else {
            $realip = getenv("REMOTE_ADDR");
        }
    }
    return $realip;
}
?>