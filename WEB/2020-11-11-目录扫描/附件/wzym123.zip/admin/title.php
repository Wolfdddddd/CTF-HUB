﻿<?php session_start();header("Content-type: text/html; charset=utf-8"); 
IF( $_SESSION['admin']!="OK"){
exit("<meta http-equiv=\"refresh\" content=\"0.1;url=index.php\">") ;      
}

include("../php/admin_function.php");
$zl=zl();

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>后台管理</title>

<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
</head>

<body>


<img class="bg-image" src="../img/bj.jpg">
<div class="bg-image-pattern"></div>


<div class="wrapper">
  <div align="center"><h2>淡然后台管理系统</h2> </div>
  


<div class="panel">
  <div class="panel-heading">
   <i class="icon icon-arrow-left"></i> <a  href="admin_index.php" class="label label-badge label-info"> 返回首页</a>-【网站信息修改】
  </div>
  <div class="panel-body">
    <span class="label">标题：</span>
	<form action="" method="post">
	<input name="admin_xx" type="hidden" id="admin_xx" value="ok">
	<input type="text" name="t" id="t" value="<?PHP ECHO $zl['t']; ?>" class="form-control" placeholder="标题">
<br>
	<span class="label">关键字：</span>
	<input type="text" name="g" id="g" value="<?PHP ECHO $zl['g']; ?>" class="form-control" placeholder="关键字">
	<br>
	<span class="label">描述：</span>
	<input name="m" type="text" class="form-control" id="m" value="<?PHP ECHO $zl['m']; ?>" placeholder="描述">
	<br>
	<span class="label">站长QQ：</span>
	<input type="text" name="q" id="q" value="<?PHP ECHO $zl['q']; ?>" class="form-control" placeholder="QQ">
	<br>
	
	<span class="label">二级标题：</span>
	<input type="text" name="tt" id="tt" value="<?PHP ECHO $zl['tt']; ?>" class="form-control" placeholder="二级标题">
	<br>
	<input class="btn btn-block btn-info  " name="立即修改" type="submit" id="立即修改" value="立即修改">
	
	</form>

  
  




</div>
  

  </div>
 版权归安小浩所有@2016 
</div>


<?PHP

if($_POST['admin_xx']=="ok"){
    
IF(zl_g($_POST['t'],$_POST['g'],$_POST['m'],$_POST['q'],$_POST['tt'])){
    
 echo "<script>alert('修改成功！')</script>";
   exit("<meta http-equiv=\"refresh\" content=\"0.1;url=title.php\">") ;       
    
}echo "<script>alert('修改失败！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  
    
    
}


?>






 <script src="../js/jquery.js"></script>
  <script src="../js/zui.min.js"></script>
  <script src="../js/zui.js"></script>
  <script src="../js/zui.lite.js"></script>
  <script src="../js/zui.lite.min.js"></script>
  <script src="../js/zui.min.js"></script>
   <script src="../js/yzm.js"></script>
   
   
   

   
   
</body>
</html>
