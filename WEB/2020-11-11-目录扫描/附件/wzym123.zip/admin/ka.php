﻿<?php session_start();header("Content-type: text/html; charset=utf-8"); 
IF( $_SESSION['admin']!="OK"){
exit("<meta http-equiv=\"refresh\" content=\"0.1;url=index.php\">") ;      
}

include("../php/admin_function.php");
$ka=ka();

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>后台管理</title>

<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
</head>

<body>


<img class="bg-image" src="../img/bj.jpg">
<div class="bg-image-pattern"></div>


<div class="wrapper">
  <div align="center"><h2>萌耗子后台管理系统</h2> </div>
  


<div class="panel">
  <div class="panel-heading">
   <i class="icon icon-arrow-left"></i> <a  href="admin_index.php" class="label label-badge label-info"> 返回首页</a>-【网站卡盟配置】
  </div>
  <div class="panel-body">
    <span class="label">卡盟地址：</span>
	<form action="" method="post">
	<input name="admin_xx" type="hidden" id="admin_xx" value="ok">
	<input type="text" name="url" id="url" value="http://danran.999km.cn/" class="form-control" placeholder="http://danran.999km.cn/">
<br>
	<span class="label">卡盟账号：</span>
	<input type="text" name="u" id="u" value="<?PHP ECHO $ka['u']; ?>" class="form-control" placeholder="账号">
	<br>
	<span class="label">卡盟密码：</span>
	<input name="p" type="text" class="form-control" id="p" value="<?PHP ECHO $ka['p']; ?>" placeholder="密码">
	<br>
	<span class="label">交易密码：</span>
	<input type="text" name="j" id="j" value="<?PHP ECHO $ka['j']; ?>" class="form-control" placeholder="交易密码">
	<br>
	
	
	<input class="btn btn-block btn-info  " name="立即修改" type="submit" id="立即修改" value="立即修改">
	
	</form>

  
  




</div>
  

  </div>
 版权归安小浩所有@2016 
</div>


<?PHP

if($_POST['admin_xx']=="ok"){
    
if($_POST['url']=="" || $_POST['u']=="" || $_POST['p']=="" || $_POST['j']=="")	{
echo "<script>alert('请填写完整！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  
}

	
	
	
IF(ka_g($_POST['url'],$_POST['u'],$_POST['p'],$_POST['j'])){
    
 echo "<script>alert('修改成功！')</script>";
   exit("<meta http-equiv=\"refresh\" content=\"0.1;url=ka.php\">") ;       
    
}echo "<script>alert('修改失败！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  
    
    
}


?>






 <script src="../js/jquery.js"></script>
  <script src="../js/zui.min.js"></script>
  <script src="../js/zui.js"></script>
  <script src="../js/zui.lite.js"></script>
  <script src="../js/zui.lite.min.js"></script>
  <script src="../js/zui.min.js"></script>
   <script src="../js/yzm.js"></script>
   
   
   

   
   
</body>
</html>
