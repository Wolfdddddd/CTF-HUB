﻿<?php session_start();header("Content-type: text/html; charset=utf-8"); 
IF( $_SESSION['admin']!="OK"){
exit("<meta http-equiv=\"refresh\" content=\"0.1;url=index.php\">") ;      
}
include("../php/admin_function.php");

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width; initial-scale=1.0;  minimum-scale=1.0; maximum-scale=2.0"/>
<title>后台管理</title>

<link href="../css/zui.css" rel="stylesheet" type="text/css" />
<link href="../css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="../css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="../css/css.css" rel="stylesheet" type="text/css" />
</head>

<body>


<img class="bg-image" src="../img/bj.jpg">
<div class="bg-image-pattern"></div>


<div class="wrapper">
  <div align="center"><h2>淡然后台管理系统</h2> </div>
  
  <div class="panel">
  <div class="panel-heading">
   <i class="icon icon-arrow-left"></i> <a  href="admin_index.php" class="label label-badge label-info"> 返回首页</a>-【业务管理】
  </div>
  <div class="panel-body">

<div id="JJ">
<span class="label">添加商品：</span>
<input type="text" name="kameng_shangpin" id="kameng_shangpin" value="" class="form-control" placeholder="请输入卡盟商品地址">
<br/>
<input class="btn btn-block btn-info  " onclick="tj()" name="读取商品" type="submit" id="读取商品" value="读取商品">










</div>



</div>
  
  </div> 
  
  
  
  
  
  
  
  
  
   <div class="panel">
  <div class="panel-heading">
   业务列表
  </div>
  <div class="panel-body">



<table class="table table-hover">
<thead>
<tr>
    <td>ID</td>
    <td>业务</td>
    <td>删除</td>
  </tr>
</thead>
  
 
 
 <?PHP ywl(); ?>
  
  
 
  
 
  
</table>







</div> 
  
  
  
  
  
  

  </div>
 版权归淡然所有@2016 
</div>





<?php
if($_GET['id']!=""){
   if( yw_s($_GET['id'])){
    
    echo "<script>alert('删除成功！')</script>";
   exit("<meta http-equiv=\"refresh\" content=\"0.1;url=yw.php\">") ; 
    
    
   }echo "<script>alert('删除失败！')</script>";
   exit("<script language=\"javascript\">location.href = 'javascript:history.back()'</script>");  
    
    
}


?>



 <script src="../js/jquery.js"></script>
  <script src="../js/zui.min.js"></script>
  <script src="../js/zui.js"></script>
  <script src="../js/zui.lite.js"></script>
  <script src="../js/zui.lite.min.js"></script>
  <script src="../js/zui.min.js"></script>
   <script src="../js/yzm.js"></script>
   <script src="../js/shangpin.js"></script>
   
   
   
  
   
   
</body>
</html>
